// Attendre que le DOM soit complètement chargé avant d'exécuter le script
document.addEventListener('DOMContentLoaded', function () {

  // 1. Récupérer les 20 premiers établissements via l'API Open Data
  fetch('https://data.enseignementsup-recherche.gouv.fr/api/records/1.0/search/?dataset=fr-esr-principaux-etablissements-enseignement-superieur&rows=20&format=json')
    .then(response => {
      // Vérifier si la réponse HTTP est correcte (statut 200)
      if (!response.ok) throw new Error('Erreur HTTP ' + response.status);
      // Convertir la réponse en objet JSON
      return response.json();
    })
    .then(data => {
      // Extraire uniquement les champs utiles de chaque établissement
      const etablissements = data.records.map(rec => rec.fields);
      // Appeler la fonction pour afficher le tableau dans la page
      afficherTableauEtablissements(etablissements);
    })
    .catch(error => {
      // En cas d'erreur (réseau, API, etc.), afficher un message d'erreur dans la console
      console.error('Erreur lors de la récupération des données :', error);
      // Et afficher un message d'erreur dans la page web
      const div = document.getElementById('tableau-etablissements');
      if (div) div.textContent = "Erreur de chargement des données.";
    });

  // 2. Fonction pour générer et afficher le tableau HTML
  function afficherTableauEtablissements(etablissements) {
    // Sélectionner la div où afficher le tableau
    const div = document.getElementById('tableau-etablissements');
    if (!div) return; // Si la div n'existe pas, arrêter la fonction

    // Début du tableau HTML avec en-têtes de colonnes
    let html = `
      <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%;">
        <thead>
          <tr>
            <th>Nom</th>
            <th>Type</th>
            <th>Ville</th>
            <th>Académie</th>
            <th>Pays</th>
            <th>Site web</th>
          </tr>
        </thead>
        <tbody>`;

    // Pour chaque établissement, créer une ligne du tableau
    etablissements.forEach(etab => {
      html += `
        <tr>
          <td>${etab.uo_lib || 'N/A'}</td> <!-- Nom de l'établissement -->
          <td>${etab.type_d_etablissement || 'N/A'}</td> <!-- Type d'établissement -->
          <td>${etab.com_nom || etab.localite_acheminement_uai || 'N/A'}</td> <!-- Ville (ou localité si ville absente) -->
          <td>${etab.aca_nom || 'N/A'}</td> <!-- Académie -->
          <td>${etab.pays_etranger_acheminement || 'France'}</td> <!-- Pays (France par défaut) -->
          <td>${etab.url ? `<a href="${etab.url}" target="_blank">Site</a>` : 'N/A'}</td> <!-- Lien vers le site web si disponible -->
        </tr>`;
    });

    // Fin du tableau HTML
    html += `
        </tbody>
      </table>`;
      
    // Insérer le tableau généré dans la div de la page
    div.innerHTML = html;
  }
});
