#=========================================================================
# Nom du fichier   : MaelBot.py
# Rôle             : ChatBot MaelBot avec questions et réponses configurées
# Auteur           : Maël Khonde Mbumba | Numéro d’étudiant : 24000486
# Date de création : 17/07/2025
# Version          : 1.0
# Licence          : Exercice dans le cadre du cours de OUR
# Compilation.     : (Pas de compilation, interprété avec Python 3)
# Usage            : Pour exécuter : MaelBot.py               
# =========================================================================

import re  # Importation du module pour les expressions régulières
from datetime import datetime  # Importation de la classe datetime pour gérer les dates et heures

def get_today():
    # Retourne la date du jour formatée (exemple : "Wednesday 16 July 2025")
    return datetime.now().strftime("%A %d %B %Y")

def get_time():
    # Retourne l'heure actuelle formatée (exemple : "18:34:52")
    return datetime.now().strftime("%H:%M:%S")

def chatbot_response(user_input):
    # Conversion de l'entrée utilisateur en minuscules pour faciliter la comparaison
    user_input = user_input.lower()

    # Dictionnaire associant des motifs (regex) à des réponses prédéfinies
    faq = {
        r"\bbonjour\b|\bsalut\b": "Bonjour ! Je suis MaelBot. Que puis-je faire pour vous ? 😊",
        r"\bbonsoir\b": "Bonsoir ! Comment puis-je vous aider ? 🌙",
        r"(comment tu t'appelles|quel est ton nom)": "Je suis MaelBot, votre assistant virtuel 🤖.",
        r"(quel est ton langage|tu es codé en quoi)": "Je suis développé en Python avec Flask 🐍.",
        r"(que fais|quel est ton rôle)": "Je suis là pour répondre à vos questions simples et vous aider.",
        r"(qui t'a créé|qui est ton créateur)": "J’ai été conçu par un étudiant talentueux pour un TP 💡.",
        r"(quel jour sommes-nous|date du jour)": f"Aujourd'hui, nous sommes le {get_today()} 📅.",
        r"(quelle heure est-il|donne-moi l'heure)": f"Il est actuellement {get_time()} ⏰.",
        r"(merci|thanks)": "Avec plaisir ! 😊",
        r"(au revoir|bye|à bientôt)": "À bientôt ! 👋",
        r"(quel âge as-tu)": "Je suis tout jeune, je viens d'être créé pour ce projet 😄.",
        r"(tu fais quoi|tu sers à quoi)": "Je suis un chatbot éducatif. J'aide dans les projets de TP 📘.",
        r"(comment vas-tu|ça va)": "Je vais très bien, merci ! Et vous ?",
        r"(tu connais chatgpt)": "Oui ! Je suis inspiré par ChatGPT, mais en version locale 😉.",
        r"(as-tu des frères|autres bots)": "Non, je suis unique pour ce projet, mais je peux évoluer !",
        r"(quel est ton créateur|qui t'a conçu)": "Mon créateur est un(e) étudiant(e) passionné(e) !",
    }

    # Parcourt chaque motif et réponse dans la FAQ
    for pattern, response in faq.items():
        # Si l'entrée utilisateur correspond au motif, retourne la réponse associée
        if re.search(pattern, user_input):
            return response

    # Si aucun motif ne correspond, retourne une réponse par défaut
    return "Désolé, je n’ai pas compris. Pouvez-vous reformuler ? 🤔"
