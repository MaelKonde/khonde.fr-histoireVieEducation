#=========================================================================
# Nom du fichier   : flaskApps.py
# Rôle             : Flask pour lancer et faire fonctionner MaelBot
# Auteur           : Maël Khonde Mbumba | Numéro d’étudiant : 24000486
# Date de création : 16/07/2025
# Version          : 1.0
# Licence          : Exercice dans le cadre du cours de OUR
# Compilation.     : (Pas de compilation, interprété avec Python 3)
# Usage            : Pour exécuter : flaskApps.py               
# =========================================================================

# Importation des modules nécessaires depuis Flask
from flask import Flask, render_template, request, session
# Importation de la fonction de réponse du chatbot depuis le module MaelBot
from MaelBot import chatbot_response

# Création de l'application Flask
app = Flask(__name__)
# Clé secrète nécessaire pour utiliser les sessions (stockage côté serveur)
app.secret_key = "maelbot_secret"

# Définition de la route principale ("/") acceptant les méthodes GET et POST
@app.route("/", methods=["GET", "POST"])
def index():
    # Initialisation de l'historique de chat si ce n'est pas déjà en session
    if "chat_history" not in session:
        session["chat_history"] = []

    # Si le formulaire a été soumis (requête POST)
    if request.method == "POST":
        # Récupération de l'entrée utilisateur depuis les champs du formulaire HTML
        user_input = request.form["user_input"]
        # Appel de la fonction chatbot pour obtenir une réponse
        bot_reply = chatbot_response(user_input)
        # Ajout du message utilisateur et de la réponse du bot à l'historique de chat
        session["chat_history"].append({"user": user_input, "bot": bot_reply})
        # Indique que la session a été modifiée (important pour Flask)
        session.modified = True

    # Affiche le template "index.html" avec l'historique des échanges
    return render_template("index.html", chat_history=session["chat_history"])

# Point d’entrée de l’application Flask
if __name__ == "__main__":
    # Lancement du serveur en mode debug (utile pour le développement)
    app.run(debug=True)
